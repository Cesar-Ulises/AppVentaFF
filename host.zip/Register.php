<?php
    $con = mysqli_connect("localhost","id11607027_adm","123456789","id11607027_bdapp1");

    $titulo = $_POST["titulo"];
    $autor = $_POST["autor"];
    $letra = $_POST["letra"];

    $statement = mysqli_prepare($con, "INSERT INTO alabanza (titulo, autor, letra ) VALUES
        ('$titulo', '$autor', '$letra')");

    $response = array();
    $response["success"] = true;

    echo json_encode($response);
    mysqli_close($con);
?>